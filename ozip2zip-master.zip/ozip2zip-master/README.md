# ozip2zip
OPPO firmware ozip to zip

Requirement
---
Python 3.X with pycryptodome

```pip install pycryptodome```

Usage
---

```ozip2zip.py <*.ozip>```

Supported Devices
---

```
OPPO R9s
OPPO R9s plus
OPPO R11
OPPO R11s
OPPO R11s plus
OPPO A73
OPPO A83
OPPO K1
OPPO R15
OPPO R17 Neo (AX7 Pro)
OPPO Find X
Realme 1
Realme 3
Realme X
Realme XT
Realme X2 Pro
```
